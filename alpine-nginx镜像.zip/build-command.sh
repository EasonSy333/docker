#!/bin/bash
docker build -t alpine-nginx:v1.16.1 .
